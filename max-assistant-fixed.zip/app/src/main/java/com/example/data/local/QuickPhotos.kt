package com.example.data.local

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Photos the user saves once inside the app (QR code, ID, etc.) so they can be shown
 * instantly by voice: "Max, QR nikalo".
 */
object QuickPhotos {
    private fun dir(context: Context): File = File(context.filesDir, "quick_photos").apply { mkdirs() }

    fun sanitize(label: String): String =
        label.lowercase().trim().replace(Regex("[^a-z0-9\\u0900-\\u097F]+"), "_").trim('_')

    fun list(context: Context): List<String> =
        (dir(context).listFiles()?.map { it.nameWithoutExtension } ?: emptyList()).sorted()

    fun fileFor(context: Context, label: String): File? {
        val f = File(dir(context), sanitize(label) + ".img")
        return if (f.exists()) f else null
    }

    fun save(context: Context, label: String, uri: Uri): Boolean {
        val clean = sanitize(label)
        if (clean.isBlank()) return false
        return try {
            val copied = context.contentResolver.openInputStream(uri)?.use { input ->
                File(dir(context), "$clean.img").outputStream().use { out -> input.copyTo(out) }
                true
            }
            copied == true
        } catch (e: Exception) {
            false
        }
    }

    fun delete(context: Context, label: String) {
        File(dir(context), sanitize(label) + ".img").delete()
    }
}
