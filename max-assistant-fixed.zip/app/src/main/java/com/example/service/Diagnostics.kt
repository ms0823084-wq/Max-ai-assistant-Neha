package com.example.service

import kotlinx.coroutines.flow.MutableStateFlow

/** Live status shown on the main screen, so it is clear what the assistant heard and why it did (or did not) act. */
object Diagnostics {
    val state = MutableStateFlow("-")
    val lastHeard = MutableStateFlow("-")
    val lastCommand = MutableStateFlow("-")
    val brain = MutableStateFlow("-")
    val lastError = MutableStateFlow("")
}
