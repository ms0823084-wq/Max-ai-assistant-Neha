package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import com.example.MaxApplication

/** Announces who is calling: "Papa ka call aa raha hai". Needs Phone, Call log and Contacts permissions. */
class CallStateReceiver : BroadcastReceiver() {
    companion object {
        private var lastNumber = ""
        private var lastTime = 0L
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val i = intent ?: return
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return
        @Suppress("DEPRECATION")
        val number = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: return

        val app = context.applicationContext as MaxApplication
        val sm = app.securityManager
        if (!sm.isListeningActive || sm.isAssistantOff) return
        val now = System.currentTimeMillis()
        if (number == lastNumber && now - lastTime < 20000) return
        lastNumber = number
        lastTime = now

        var name: String? = null
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            val c: Cursor? = context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            c?.use { if (it.moveToFirst()) name = it.getString(0) }
        } catch (e: Exception) {
            name = null
        }
        val who = name ?: number.toCharArray().joinToString(" ")
        app.ttsManager.speak("${sm.userCallName}, $who ka call aa raha hai. Uthana ho to bolo, ${sm.assistantName} call uthao.")
    }
}
