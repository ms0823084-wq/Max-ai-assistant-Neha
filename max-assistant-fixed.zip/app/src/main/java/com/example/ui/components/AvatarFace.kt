package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.sin
/** Current emotion of the on-screen character. Set by the AI brain or guessed from the spoken text. */
object AvatarState {
    val emotion = MutableStateFlow("neutral")
    @Volatile private var manualUntil = 0L
    @Volatile var lastChange = System.currentTimeMillis()

    private fun normalize(e: String): String = when (e.lowercase()) {
        "happy", "sad", "angry", "surprised", "thinking", "love", "sleepy" -> e.lowercase()
        else -> "neutral"
    }

    fun setManual(e: String) {
        emotion.value = normalize(e)
        manualUntil = System.currentTimeMillis() + 15000L
        lastChange = System.currentTimeMillis()
    }

    fun autoFrom(text: String) {
        if (System.currentTimeMillis() < manualUntil) return
        emotion.value = guess(text)
        lastChange = System.currentTimeMillis()
    }

    fun reset() {
        emotion.value = "neutral"
    }

    fun guess(text: String): String {
        val t = text.lowercase()
        return when {
            t.contains("haha") || t.contains("wah") || t.contains("badhiya") || t.contains("mubarak") ||
                    t.contains("great") || t.contains("khushi") || t.contains("mazaa") -> "happy"
            t.contains("sorry") || t.contains("maaf") || t.contains("dukh") || t.contains("udaas") ||
                    t.contains("nahi ho paya") || t.contains("nahi mila") -> "sad"
            t.contains("arre") || t.contains("wow") || t.contains("kya baat") -> "surprised"
            t.contains("pyaar") || t.contains("love") || t.contains("dil se") -> "love"
            t.contains("shubh ratri") || t.contains("good night") || t.contains("neend") -> "sleepy"
            t.contains("soch") || t.contains("hmm") || t.contains("dhundh raha") -> "thinking"
            else -> "neutral"
        }
    }
}

@Composable
fun AvatarPhoto(
    emotion: String,
    speaking: Boolean,
    modifier: Modifier = Modifier,
    avatarSize: Dp = 170.dp
) {
    val transition = rememberInfiniteTransition(label = "avatar")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (speaking) 1.045f else 1.012f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (speaking) 380 else 2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val ringAlpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = if (speaking) 1f else 0.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (speaking) 450 else 2200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ring"
    )
    val wave by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(animation = tween(900, easing = LinearEasing)),
        label = "wave"
    )
    val ringColor = when (emotion) {
        "happy" -> Color(0xFFFFD54F)
        "sad" -> Color(0xFF64B5F6)
        "angry" -> Color(0xFFFF5252)
        "surprised" -> Color(0xFFFFAB40)
        "love" -> Color(0xFFFF80AB)
        "sleepy" -> Color(0xFF9FA8DA)
        "thinking" -> Color(0xFFB388FF)
        else -> Color(0xFF00E5FF)
    }

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(modifier = Modifier.size(avatarSize + 24.dp), contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(avatarSize + 16.dp)
                    .scale(pulse)
                    .border(3.dp, ringColor.copy(alpha = ringAlpha), CircleShape)
            )
            Image(
                painter = painterResource(R.drawable.avatar_photo),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(avatarSize)
                    .scale(pulse)
                    .clip(CircleShape)
            )
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.height(30.dp)
        ) {
            if (speaking) {
                for (i in 0 until 9) {
                    val h = 6f + 20f * (0.5f + 0.5f * sin(wave + i * 0.8f))
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(h.dp)
                            .clip(CircleShape)
                            .background(ringColor)
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
