package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PowerOff
import androidx.compose.material.icons.filled.ScreenLockPortrait
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MaxApplication
import com.example.ui.theme.BrightCoral
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.DarkSapphire
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GoldenAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AntiTheftScreen(
    onNavigateToIntruderLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val app = context.applicationContext as MaxApplication

    var isArmed by remember { mutableStateOf(app.securityManager.isAntiTheftArmed) }
    val isAlarmSounding by app.antiTheftController.isAlarmSounding.collectAsState()

    var showDisarmDialog by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinErrorMessage by remember { mutableStateOf<String?>(null) }

    var emergencyContact by remember { mutableStateOf(app.securityManager.emergencyContact) }
    var storedPin by remember { mutableStateOf(app.securityManager.antiTheftPin) }
    var spokenPassphrase by remember { mutableStateOf(app.securityManager.antiTheftPassphrase) }

    var alarmOnUnplug by remember { mutableStateOf(app.securityManager.isChargerAlarmEnabled) }
    var alarmOnMovement by remember { mutableStateOf(app.securityManager.isMovementAlarmEnabled) }
    var alarmOnWrongPin by remember { mutableStateOf(app.securityManager.isWrongPinAlarmEnabled) }
    var motionThreshold by remember { mutableFloatStateOf(app.securityManager.motionSensitivity) }

    val logsCount by app.database.intruderDao().getAllLogs().collectAsState(initial = emptyList())

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberNavy)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Top Security Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Security,
                    contentDescription = "Anti-Theft",
                    tint = if (isArmed) BrightCoral else NeonCyan,
                    modifier = Modifier.size(30.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "ANTI-THEFT SYSTEM",
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        fontSize = 17.sp
                    )
                    Text(
                        text = if (isArmed) "ARMED & MONITORING" else "DISARMED",
                        color = if (isArmed) BrightCoral else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Siren Test button
            Button(
                onClick = {
                    if (isAlarmSounding) {
                        app.antiTheftController.stopSiren()
                    } else {
                        app.antiTheftController.triggerAlarm("Manual Siren Test")
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isAlarmSounding) BrightCoral else DarkSapphire
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("siren_test_button")
            ) {
                Icon(Icons.Default.VolumeUp, contentDescription = "Test Siren", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (isAlarmSounding) "Stop Siren" else "Test Siren", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Flashing Warning Banner when Alarm is Sounding
        AnimatedVisibility(visible = isAlarmSounding) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = BrightCoral),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Campaign, contentDescription = "Alarm", tint = Color.White, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SIREN ALARM SOUNDING AT MAX VOLUME!",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = { showDisarmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("DISARM ALARM WITH PIN", color = BrightCoral, fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }

        // Large Arming Toggle Banner
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isArmed) BrightCoral.copy(alpha = 0.15f) else SlateCard
            ),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    2.dp,
                    if (isArmed) BrightCoral else DarkSapphire,
                    RoundedCornerShape(20.dp)
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(if (isArmed) BrightCoral else EmeraldGreen.copy(alpha = 0.2f))
                        .clickable {
                            if (isArmed) {
                                showDisarmDialog = true
                            } else {
                                isArmed = true
                                app.securityManager.isAntiTheftArmed = true
                                app.antiTheftController.onArmStateChanged(true)
                                app.ttsManager.speak("Anti-Theft armed. 3 second grace period active. Siren will sound if moved or unplugged.")
                            }
                        }
                        .testTag("arm_toggle_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isArmed) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "Arm status",
                        tint = if (isArmed) Color.White else EmeraldGreen,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isArmed) "Tap to Disarm (PIN Required)" else "Tap to Arm Security",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = if (isArmed) "Armed! 750-1350Hz Police Siren + Silent Front Camera ready."
                    else "Ready to guard your phone against thieves with siren, front selfie, and GPS alert.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Intruder Log Shortcut Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigateToIntruderLogs() }
                .border(1.dp, NeonCyan.copy(alpha = 0.25f), RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.PhotoCamera,
                        contentDescription = "Intruder Logs",
                        tint = GoldenAmber,
                        modifier = Modifier.size(26.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Intruder Selfies & Location Logs", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("${logsCount.size} captured events recorded", color = TextSecondary, fontSize = 12.sp)
                    }
                }
                Surface(
                    shape = CircleShape,
                    color = DarkSapphire
                ) {
                    Text(
                        text = "${logsCount.size}",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Trigger Conditions Section
        Text("Trigger Conditions & Sensitivity", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DeepSlate),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Charger unplug
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PowerOff, contentDescription = "Charger", tint = GoldenAmber)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Charger Unplugged Alarm", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("Triggers siren if cable is disconnected while armed", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                    Switch(
                        checked = alarmOnUnplug,
                        onCheckedChange = {
                            alarmOnUnplug = it
                            app.securityManager.isChargerAlarmEnabled = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                    )
                }

                // Phone movement
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Vibration, contentDescription = "Motion", tint = NeonCyan)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Motion / Picked Up Alarm", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text("Accelerometer movement detection", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                        Switch(
                            checked = alarmOnMovement,
                            onCheckedChange = {
                                alarmOnMovement = it
                                app.securityManager.isMovementAlarmEnabled = it
                                if (isArmed) app.antiTheftController.onArmStateChanged(true)
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                        )
                    }

                    if (alarmOnMovement) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Motion Sensitivity", color = TextSecondary, fontSize = 12.sp)
                            Text(
                                if (motionThreshold <= 2.2f) "High (Sensitive)" else if (motionThreshold <= 3.8f) "Medium" else "Low (Hard Shake)",
                                color = GoldenAmber,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = motionThreshold,
                            onValueChange = {
                                motionThreshold = it
                                app.securityManager.motionSensitivity = it
                            },
                            valueRange = 1.8f..5.5f,
                            colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = DarkSapphire)
                        )
                    }
                }

                // Wrong Lock PIN
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ScreenLockPortrait, contentDescription = "PIN", tint = BrightCoral)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Wrong Unlock PIN Alarm", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("DeviceAdmin captures selfie and sounds alarm", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                    Switch(
                        checked = alarmOnWrongPin,
                        onCheckedChange = {
                            alarmOnWrongPin = it
                            app.securityManager.isWrongPinAlarmEnabled = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = BrightCoral)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Direct Simulation Test Section
        Text("Interactive Simulation & Tests", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SlateCard),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Test your device's anti-theft response instantly:", color = TextSecondary, fontSize = 12.sp)

                Button(
                    onClick = {
                        app.antiTheftController.triggerAlarm("Simulated Wrong Unlock Attempt")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrightCoral),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("simulate_intrusion_button")
                ) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = "Test Intrusion", tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Simulate Intrusion (Siren + Front Selfie + GPS)", color = Color.White, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        app.antiTheftController.triggerAlarm("Simulated Charger Disconnect")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSapphire),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PowerOff, contentDescription = "Test Charger", tint = GoldenAmber)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Test Charger Disconnect Trigger", color = GoldenAmber)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Credentials & Alerts Section
        Text("Security Credentials & Alerts", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DeepSlate),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // PIN
                OutlinedTextField(
                    value = storedPin,
                    onValueChange = {
                        storedPin = it
                        app.securityManager.antiTheftPin = it
                    },
                    label = { Text("Disarm PIN (default: 1234)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = DarkSapphire
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Spoken Passphrase
                OutlinedTextField(
                    value = spokenPassphrase,
                    onValueChange = {
                        spokenPassphrase = it
                        app.securityManager.antiTheftPassphrase = it
                    },
                    label = { Text("Spoken Disarm Passphrase (default: 'khul ja sim sim')") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = DarkSapphire
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Emergency Contact
                OutlinedTextField(
                    value = emergencyContact,
                    onValueChange = {
                        emergencyContact = it
                        app.securityManager.emergencyContact = it
                    },
                    label = { Text("Trusted Emergency Contact (Phone Number)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = DarkSapphire
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // Disarm Dialog
    if (showDisarmDialog) {
        AlertDialog(
            onDismissRequest = {
                showDisarmDialog = false
                enteredPin = ""
                pinErrorMessage = null
            },
            shape = RoundedCornerShape(20.dp),
            containerColor = DeepSlate,
            title = {
                Text("Disarm Anti-Theft", color = TextPrimary, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        "Enter your security PIN or spoken passphrase to disarm:",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = enteredPin,
                        onValueChange = { enteredPin = it },
                        label = { Text("PIN or Passphrase") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    pinErrorMessage?.let {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(it, color = BrightCoral, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = app.antiTheftController.disarm(enteredPin)
                        if (success) {
                            isArmed = false
                            showDisarmDialog = false
                            enteredPin = ""
                            pinErrorMessage = null
                        } else {
                            pinErrorMessage = "Incorrect PIN or passphrase."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                    modifier = Modifier.testTag("disarm_confirm_button")
                ) {
                    Text("Disarm", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        showDisarmDialog = false
                        enteredPin = ""
                        pinErrorMessage = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SlateCard)
                ) {
                    Text("Cancel", color = TextPrimary)
                }
            }
        )
    }
}
