package com.example.speech

import android.content.Context
import com.example.service.Diagnostics
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.example.data.local.SecurityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sqrt

class SpeechManager(
    private val context: Context,
    private val securityManager: SecurityManager,
    private val listener: SpeechEventsListener,
    private val requireWakeWord: Boolean = false
) {

    interface SpeechEventsListener {
        fun onWakeWordDetected(keyword: String)
        fun onCommandRecognized(command: String)
        fun onPartialSpeech(partial: String)
        fun onRmsChanged(rmsDb: Float)
        fun onSpeechError(error: String)
        fun onListeningStateChanged(isListening: Boolean)
        fun onPowerStateChanged(isOn: Boolean) {}
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognizerActive = false
    @Volatile private var lastActivity = System.currentTimeMillis()
    private var vadJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private var autoGainControl: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    var isContinuousListeningEnabled = false
        private set

    /** Set by the service so the assistant never reacts to its own spoken replies. */
    var shouldIgnore: () -> Boolean = { false }
    private var ignoreCurrent = false
    private var awakeUntil = 0L
    private val awakeWindowMs = 15000L

    fun initialize() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            listener.onSpeechError("Speech recognition service not available on this device.")
            return
        }
        setupRecognizer()
    }

    private fun setupRecognizer() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        lastActivity = System.currentTimeMillis()
                        listener.onListeningStateChanged(true)
                    }

                    override fun onBeginningOfSpeech() {
                        // Ignore the assistant's own voice picked up by the microphone.
                        if (shouldIgnore()) ignoreCurrent = true
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        listener.onRmsChanged(rmsdB)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        listener.onListeningStateChanged(false)
                    }

                    override fun onError(error: Int) {
                        lastActivity = System.currentTimeMillis()
                        isRecognizerActive = false
                        listener.onListeningStateChanged(false)
                        // If continuous listening is enabled, restart after a brief moment unless client cancelled
                        if (isContinuousListeningEnabled && error != SpeechRecognizer.ERROR_CLIENT) {
                            scope.launch(Dispatchers.Main) {
                                kotlinx.coroutines.delay(300)
                                if (isContinuousListeningEnabled) {
                                    startListening()
                                }
                            }
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        lastActivity = System.currentTimeMillis()
                        isRecognizerActive = false
                        listener.onListeningStateChanged(false)
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val skip = ignoreCurrent || shouldIgnore()
                        ignoreCurrent = false
                        if (!skip && !matches.isNullOrEmpty()) {
                            val recognizedText = matches[0].trim()
                            Diagnostics.lastHeard.value = recognizedText.take(80)
                            processRecognizedText(recognizedText)
                        }

                        // Loop if continuous
                        if (isContinuousListeningEnabled) {
                            scope.launch(Dispatchers.Main) {
                                kotlinx.coroutines.delay(120)
                                if (isContinuousListeningEnabled) {
                                    startListening()
                                }
                            }
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val partial = matches[0].trim()
                            listener.onPartialSpeech(partial)

                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error creating SpeechRecognizer", e)
        }
    }

    fun startListening() {
        if (isRecognizerActive) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-IN", "en-US", "hi"))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            isRecognizerActive = true
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isRecognizerActive = false
            Log.e("SpeechManager", "Failed to start listening", e)
        }
    }

    /** Called by the service every few seconds: restarts the recognizer if Android silently killed it. */
    fun ensureListening() {
        if (!isContinuousListeningEnabled) return
        val idle = System.currentTimeMillis() - lastActivity
        if (!isRecognizerActive || idle > 30000L) {
            isRecognizerActive = false
            try {
                setupRecognizer()
            } catch (e: Exception) {
                // ignore
            }
            startListening()
            lastActivity = System.currentTimeMillis()
        }
    }

    fun stopListening() {
        isContinuousListeningEnabled = false
        isRecognizerActive = false
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            // Ignored
        }
        listener.onListeningStateChanged(false)
        stopVadRecording()
    }

    fun enableAlwaysListening() {
        isContinuousListeningEnabled = true
        startListening()
        startVadRecording()
    }

    /**
     * Hardware AGC and Noise Suppressor AudioRecord loop for hearing soft voices & VAD energy.
     */
    private fun startVadRecording() {
        if (audioRecord != null) return
        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(2048)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            val sessionId = audioRecord?.audioSessionId ?: 0
            if (sessionId != 0) {
                // Enable Automatic Gain Control for hearing soft voices
                if (AutomaticGainControl.isAvailable()) {
                    autoGainControl = AutomaticGainControl.create(sessionId)?.apply {
                        enabled = true
                    }
                }
                // Enable Noise Suppressor
                if (NoiseSuppressor.isAvailable()) {
                    noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply {
                        enabled = true
                    }
                }
            }

            audioRecord?.startRecording()

            vadJob = scope.launch(Dispatchers.IO) {
                val buffer = ShortArray(1024)
                while (isActive && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val readCount = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (readCount > 0) {
                        var sum = 0.0
                        for (i in 0 until readCount) {
                            sum += buffer[i] * buffer[i]
                        }
                        val rms = sqrt(sum / readCount)
                        val db = if (rms > 0) 20 * Math.log10(rms) else 0.0
                        // Notify VAD changes for visualizer
                        listener.onRmsChanged(db.toFloat())
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.e("SpeechManager", "Record audio permission not granted for VAD", e)
        } catch (e: Exception) {
            Log.e("SpeechManager", "Failed to start VAD AudioRecord", e)
        }
    }

    private fun stopVadRecording() {
        vadJob?.cancel()
        vadJob = null
        try {
            autoGainControl?.release()
            autoGainControl = null
            noiseSuppressor?.release()
            noiseSuppressor = null
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            // Ignored
        }
    }

    private fun nameVariants(name: String): List<String> =
        NameUtils.variants(name, securityManager.assistantNameHindi)

    /** All phrases that wake the assistant: the wake word, and just the name ("Max"). Longest first. */
    private fun wakePhrases(): List<String> {
        val out = mutableListOf<String>()
        val wake = securityManager.wakeWord.lowercase(Locale.ROOT).trim()
        if (wake.isNotBlank()) out.add(wake)
        for (v in nameVariants(securityManager.assistantName)) {
            if (v.isBlank()) continue
            for (p in listOf("bolo", "hey", "hi", "hello", "suno", "ok", "ओके", "हे", "बोलो", "सुनो")) {
                out.add("$p $v")
            }
            out.add(v)
        }
        return out.distinct().sortedByDescending { it.length }
    }

    private fun findWake(text: String): MatchResult? {
        val lower = text.lowercase(Locale.ROOT).replace("\u093C", "")
        for (p in wakePhrases()) {
            val rx = Regex("(?<![\\p{L}\\p{M}])" + Regex.escape(p) + "(?![\\p{L}\\p{M}])")
            val m = rx.find(lower)
            if (m != null) return m
        }
        return null
    }

    private fun cleanForMatch(text: String): String =
        text.lowercase(Locale.ROOT)
            .replace("\u093C", "")
            .replace(Regex("[^\\p{L}\\p{M}\\p{N}\\s]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun powerRegex(words: String): Regex {
        val names = (nameVariants(securityManager.assistantName) + listOf(securityManager.wakeWord.lowercase(Locale.ROOT)))
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString("|") { Regex.escape(it) }
        return Regex("(?<![\\p{L}\\p{M}])(?:$names)\\s*$words(?![\\p{L}\\p{M}])")
    }

    private val offWords = "(?:off|of|आफ|ऑफ|band|बंद|sleep|so jao|सो जाओ|shut down)"
    private val onWords = "(?:on|own|आन|ऑन|chalu|चालू|jaago|jago|जागो|wake up|uth jao|उठ जाओ|start)"

    private fun processRecognizedText(text: String) {
        val now = System.currentTimeMillis()
        val clean = cleanForMatch(text)
        val shortUtterance = clean.split(" ").size <= 5

        // Power switch: "Max off" / "Max on" (works even while asleep or switched off).
        if (shortUtterance) {
            if (!securityManager.isAssistantOff && powerRegex(offWords).containsMatchIn(clean)) {
                securityManager.isAssistantOff = true
                awakeUntil = 0L
                Diagnostics.state.value = "OFF mode (Max on bolo)"
                listener.onPowerStateChanged(false)
                return
            }
            if (powerRegex(onWords).containsMatchIn(clean)) {
                securityManager.isAssistantOff = false
                awakeUntil = now + awakeWindowMs
                Diagnostics.state.value = "jaga hua"
                listener.onPowerStateChanged(true)
                return
            }
        }
        if (securityManager.isAssistantOff) {
            Diagnostics.state.value = "OFF mode (Max on bolo)"
            return
        }

        val wake = findWake(text)
        var command = text
        if (wake != null) {
            command = text.lowercase(Locale.ROOT).replace("\u093C", "").removeRange(wake.range)
                .trim().trim(',', '.', '!', '?', ' ')
            awakeUntil = now + awakeWindowMs
            Diagnostics.state.value = "jaga hua"
            if (command.isBlank()) {
                listener.onWakeWordDetected(securityManager.wakeWord)
                return
            }
        } else if (requireWakeWord) {
            if (now > awakeUntil) {
                Diagnostics.state.value = "so raha hai (pehle Max bolo)"
                return
            }
            awakeUntil = now + awakeWindowMs
        }

        if (command.isNotBlank()) {
            listener.onCommandRecognized(command)
        }
    }

    fun destroy() {
        stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
