package com.example.ai

import android.content.Context
import android.net.Uri
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * On-device brain (Gemma via Google LiteRT-LM). Works with no API key and no internet.
 * The model file lives in the app's private storage, never in the APK.
 */
object OfflineBrain {
    enum class Model(val label: String, val url: String, val minBytes: Long) {
        GEMMA(
            "Gemma 4 E2B (2.6 GB) - behtar",
            "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm",
            2_000_000_000L
        ),
        QWEN(
            "Qwen3 0.6B (0.6 GB) - halka",
            "https://huggingface.co/litert-community/Qwen3-0.6B/resolve/main/Qwen3-0.6B.litertlm",
            400_000_000L
        )
    }

    val statusText = MutableStateFlow("")
    val progress = MutableStateFlow(-1)

    @Volatile var loaded: Boolean = false
        private set
    @Volatile private var downloading = false

    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val executor = Executors.newSingleThreadExecutor()
    private val dispatcher = executor.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)
    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var loadedSystem: String? = null
    private var loadedGpu = false
    private var idleJob: Job? = null

    fun modelFile(c: Context): File = File(c.filesDir, "offline_model.litertlm")

    fun isReady(c: Context): Boolean {
        val f = modelFile(c)
        return f.exists() && f.length() > 300_000_000L
    }

    // ------------------------------------------------------------------
    // Download / import
    // ------------------------------------------------------------------
    fun download(context: Context, model: Model) {
        if (downloading) return
        downloading = true
        val c = context.applicationContext
        Thread {
            var failed = false
            try {
                progress.value = 0
                statusText.value = "Download shuru ho raha hai..."
                val part = File(c.filesDir, "offline_${model.name}.part")
                var have = if (part.exists()) part.length() else 0L
                val builder = Request.Builder().url(model.url)
                if (have > 0) builder.header("Range", "bytes=$have-")
                http.newCall(builder.build()).execute().use { resp ->
                    when {
                        resp.code == 401 || resp.code == 403 -> {
                            failed = true
                            statusText.value = "Hugging Face ne download allow nahi kiya. Browser se download karke 'Model file chuno' dabao."
                        }
                        resp.code == 416 -> {
                            // already fully downloaded
                        }
                        !resp.isSuccessful -> {
                            failed = true
                            statusText.value = "Download error: ${resp.code}"
                        }
                        else -> {
                            val append = resp.code == 206
                            if (!append) have = 0L
                            val body = resp.body
                            if (body == null) {
                                failed = true
                                statusText.value = "Download error: khali jawab."
                            } else {
                                val len = body.contentLength()
                                val total = if (len > 0) have + len else -1L
                                body.byteStream().use { input ->
                                    FileOutputStream(part, append).use { out ->
                                        val buf = ByteArray(64 * 1024)
                                        var done = have
                                        var lastPct = -1
                                        while (true) {
                                            val n = input.read(buf)
                                            if (n < 0) break
                                            out.write(buf, 0, n)
                                            done += n
                                            if (total > 0) {
                                                val pct = (done * 100 / total).toInt()
                                                if (pct != lastPct) {
                                                    lastPct = pct
                                                    progress.value = pct
                                                    statusText.value = "Download ho raha hai: $pct%"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (!failed) finalizePart(c, part, model.minBytes)
            } catch (e: Throwable) {
                statusText.value = "Download ruk gaya: ${e.message}. Dobara dabao, wahin se shuru hoga."
            } finally {
                downloading = false
                progress.value = -1
            }
        }.start()
    }

    fun importFrom(context: Context, uri: Uri) {
        if (downloading) return
        downloading = true
        val c = context.applicationContext
        Thread {
            try {
                statusText.value = "Model file copy ho rahi hai... (thoda time lagega)"
                val part = File(c.filesDir, "offline_import.part")
                c.contentResolver.openInputStream(uri)?.use { input ->
                    part.outputStream().use { out -> input.copyTo(out, 256 * 1024) }
                }
                finalizePart(c, part, 300_000_000L)
            } catch (e: Throwable) {
                statusText.value = "Copy fail: ${e.message}"
            } finally {
                downloading = false
            }
        }.start()
    }

    private fun finalizePart(c: Context, part: File, minBytes: Long) {
        if (!part.exists() || part.length() < minBytes) {
            statusText.value = "File poori nahi hui ya model jaisi nahi lag rahi. Dobara koshish karo."
            return
        }
        unloadAsync()
        val dest = modelFile(c)
        dest.delete()
        statusText.value = if (part.renameTo(dest)) "Offline dimaag tayyar hai." else "File save nahi ho payi."
    }

    fun deleteModel(c: Context) {
        unloadAsync()
        modelFile(c).delete()
        statusText.value = "Model hata diya."
    }

    // ------------------------------------------------------------------
    // Running the model (everything on one background thread)
    // ------------------------------------------------------------------
    private fun unloadNow() {
        try {
            conversation?.close()
        } catch (e: Throwable) {
            // ignore
        }
        try {
            engine?.close()
        } catch (e: Throwable) {
            // ignore
        }
        conversation = null
        engine = null
        loadedSystem = null
        loaded = false
    }

    private fun unloadAsync() {
        scope.launch { unloadNow() }
    }

    private fun ensure(c: Context, system: String, gpu: Boolean) {
        val current = engine
        if (current != null && loadedGpu == gpu) {
            if (loadedSystem != system) {
                try {
                    conversation?.close()
                } catch (e: Throwable) {
                    // ignore
                }
                conversation = current.createConversation(
                    ConversationConfig(systemInstruction = Contents.of(system))
                )
                loadedSystem = system
            }
            return
        }
        unloadNow()
        val config = EngineConfig(
            modelPath = modelFile(c).absolutePath,
            backend = if (gpu) Backend.GPU() else Backend.CPU(),
            cacheDir = c.cacheDir.path
        )
        val e = Engine(config)
        e.initialize()
        engine = e
        conversation = e.createConversation(ConversationConfig(systemInstruction = Contents.of(system)))
        loadedSystem = system
        loadedGpu = gpu
        loaded = true
    }

    private fun scheduleIdleUnload() {
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(3 * 60 * 1000L)
            unloadNow()
        }
    }

    suspend fun reply(context: Context, text: String, system: String, useGpu: Boolean): Result<String> =
        withContext(dispatcher) {
            val c = context.applicationContext
            idleJob?.cancel()
            try {
                ensure(c, system, useGpu)
                val out = checkNotNull(conversation).sendMessage(text).toString().trim()
                scheduleIdleUnload()
                Result.success(out)
            } catch (e: Throwable) {
                unloadNow()
                if (useGpu) {
                    // GPU can fail on some phones: retry once on the CPU.
                    try {
                        ensure(c, system, false)
                        val out = checkNotNull(conversation).sendMessage(text).toString().trim()
                        scheduleIdleUnload()
                        return@withContext Result.success(out)
                    } catch (e2: Throwable) {
                        unloadNow()
                        return@withContext Result.failure(Exception(e2.message ?: "offline model error"))
                    }
                }
                Result.failure(Exception(e.message ?: "offline model error"))
            }
        }
}
