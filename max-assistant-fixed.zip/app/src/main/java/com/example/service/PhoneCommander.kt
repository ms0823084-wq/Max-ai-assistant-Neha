package com.example.service

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import com.example.MaxApplication
import com.example.ai.OfflineBrain
import com.example.ui.components.AvatarState
import com.example.data.local.MemoryNotes
import org.json.JSONObject
import com.example.data.model.ChatMessage
import com.example.data.model.PendingAction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.util.Locale

class PhoneCommander(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val scope = CoroutineScope(Dispatchers.Main)
    private val extras = VoiceExtras(context, scope) { postPendingConfirmation(it) }
    private val app: MaxApplication get() = context.applicationContext as MaxApplication

    private val _pendingAction = MutableStateFlow<PendingAction?>(null)
    val pendingAction = _pendingAction.asStateFlow()

    val navigationEvents = kotlinx.coroutines.flow.MutableSharedFlow<String>(extraBufferCapacity = 5)

    private var isTorchOn = false

    fun postPendingConfirmation(action: PendingAction) {
        _pendingAction.value = action
        val app = context.applicationContext as MaxApplication
        app.ttsManager.speak(action.spokenPrompt)
    }

    fun clearPendingConfirmation() {
        _pendingAction.value = null
    }

    fun confirmPendingAction() {
        val action = _pendingAction.value ?: return
        _pendingAction.value = null
        val app = context.applicationContext as MaxApplication

        when (action.actionType) {
            "whatsapp_send" -> {
                val recipient = action.recipient.orEmpty()
                val text = action.messageText.orEmpty()
                val sbnKey = WhatsAppNotificationListener.replyActions.keys.firstOrNull { it.contains(recipient, ignoreCase = true) }
                if (sbnKey != null && WhatsAppNotificationListener.instance?.sendDirectReply(sbnKey, text) == true) {
                    app.ttsManager.speak("Message bhej diya gaya hai.")
                } else {
                    // Fallback to WhatsApp intent
                    openWhatsAppMessage(recipient, text)
                    app.ttsManager.speak("WhatsApp khol diya hai, message ready hai.")
                }
            }
            "phone_call" -> {
                val phone = action.phoneNumber.orEmpty()
                app.ttsManager.speak("Theek hai Boss, ${action.contactName ?: phone} ko call laga raha hoon.")
                makeDirectPhoneCall(phone)
            }
            "whatsapp_call" -> {
                extras.startWhatsAppCall(action.recipient.orEmpty(), action.messageText == "video")
            }
            "siren_disarm" -> {
                app.antiTheftController.stopSiren()
                app.securityManager.isAntiTheftArmed = false
                app.ttsManager.speak("Siren band ho gaya hai aur security disarm ho gayi hai.")
            }
        }
    }

    fun rejectPendingAction() {
        _pendingAction.value = null
        val app = context.applicationContext as MaxApplication
        app.ttsManager.speak("Theek hai Boss, cancel kar diya.")
    }

    /**
     * Central entry point for processing speech command in Hindi, English, and Hinglish.
     */
    fun processVoiceCommand(input: String, fromAi: Boolean = false) {
        val app = context.applicationContext as MaxApplication
        val boss = app.securityManager.userCallName
        val normalized = input.trim()
        val lower = normalizeHindi(normalized.lowercase(Locale.ROOT))

        Diagnostics.lastCommand.value = normalized.take(80)
        Log.d("PhoneCommander", "Processing voice command: $normalized")

        // 1. Pending Action Confirmation check (Yes / Haan / Cancel)
        val pending = _pendingAction.value
        if (pending != null) {
            if (isAffirmative(lower)) {
                confirmPendingAction()
                return
            } else if (isNegative(lower)) {
                rejectPendingAction()
                return
            }
        }

        // 2. Interruption / Stop command
        if (lower == "chup" || lower == "chup raho" || lower == "stop" || lower == "ruk jao" || lower == "pause") {
            app.ttsManager.stop()
            app.antiTheftController.stopSiren()
            return
        }

        // 3. Anti-Theft Arm / Disarm
        if (lower.contains("anti theft on") || lower.contains("security on") || lower.contains("suraksha on") ||
            lower.contains("alarm arm") || lower.contains("phone ki suraksha chalu karo") || lower.contains("arm phone")
        ) {
            app.securityManager.isAntiTheftArmed = true
            app.antiTheftController.onArmStateChanged(true)
            app.ttsManager.speak("$boss, Anti-Theft security arm ho chuki hai. Koi bhi phone hilayega ya galat PIN dalega toh siren bajega.")
            return
        }

        if (lower.contains("disarm") || lower.contains("anti theft off") || lower.contains("suraksha band") || lower.contains("siren band")) {
            postPendingConfirmation(
                PendingAction(
                    actionType = "siren_disarm",
                    description = "Disarm Anti-Theft and silence siren",
                    spokenPrompt = "$boss, kya aap anti-theft security disarm karna chahte hain?"
                )
            )
            return
        }

        // Camera Vision Voice Commands: "ye kya hai", "kya hai ye", "camera vision kholo", "dawaai check karo"
        if (lower.contains("ye kya hai") || lower.contains("kya hai ye") || lower.contains("what is this") ||
            lower.contains("camera vision") || lower.contains("vision kholo") || lower.contains("ye dekho") ||
            lower.contains("currency pehchano") || lower.contains("dawaai padho")
        ) {
            navigationEvents.tryEmit("VISION")
            app.ttsManager.speak("$boss, Camera Vision khol diya hai. Frame ke saamne rakhein aur dekhein.")
            return
        }

        // Intruder Logs: "kisne phone chhua", "intruder log dikhao", "selfie dikhao"
        if (lower.contains("intruder log") || lower.contains("kisne phone chhua") || lower.contains("selfie dikhao") || lower.contains("chor ki photo")) {
            navigationEvents.tryEmit("INTRUDER_LOGS")
            app.ttsManager.speak("$boss, Intruder selfi aur logs screen khol di hai.")
            return
        }

        // Calls, media, quick settings, alarms, navigation and Voice-Access style controls
        if (extras.handle(lower)) return

        // Questions and problems go straight to the brain (Jarvis style), not through the loose command rules.
        if (!fromAi && looksLikeQuestion(lower)) {
            askBrain(normalized, false)
            return
        }

        // YouTube: play a song/video. Works for "YouTube par <song> lagao", "<artist> ka gaana lagao",
        // and "YouTube kholo aur <artist> ka gaana lagao".
        val mediaWord = lower.contains("gaana") || lower.contains("gana") || lower.contains("gaane") ||
                lower.contains("song") || lower.contains("video") || lower.contains("music")
        val playWord = lower.contains("lagao") || lower.contains("chalao") || lower.contains("play") ||
                lower.contains("bajao") || lower.contains("sunao") || lower.contains("suna do")
        val ytIntent = (mediaWord && playWord && !lower.contains("whatsapp") && !lower.contains("reel") && !lower.contains("call")) ||
                (lower.contains("youtube") && (playWord || lower.contains("search") || lower.contains("khojo") || lower.contains("dhundo")))
        if (ytIntent) {
            val stop = setOf("youtube", "par", "pe", "on", "gaana", "gana", "gaane", "song", "video", "music",
                "lagao", "chalao", "play", "bajao", "sunao", "suna", "do", "dijiye", "karo", "kholo", "open",
                "aur", "and", "then", "search", "khojo", "dhundo", "mere", "liye", "mujhe", "ek", "wala", "wali")
            val tokens = lower.split(Regex("\\s+")).filter { it.isNotBlank() && it !in stop }.toMutableList()
            val edge = setOf("ka", "ke", "ki", "ko")
            while (tokens.isNotEmpty() && tokens.first() in edge) tokens.removeAt(0)
            while (tokens.isNotEmpty() && tokens.last() in edge) tokens.removeAt(tokens.lastIndex)
            val query = tokens.joinToString(" ").trim()
            if (query.isBlank()) {
                openAppByName("YouTube")
                app.ttsManager.speak("$boss, YouTube khol diya hai. Kaunsa gaana lagana hai?")
            } else {
                playOnYouTube(query)
            }
            return
        }

        // 4. Multi-step task: e.g. "YouTube kholo aur Arijit Singh ka gaana lagao"
        if (lower.contains(" aur ") || lower.contains(" and ") || lower.contains(" then ")) {
            val steps = if (lower.contains(" aur ")) lower.split(" aur ") else if (lower.contains(" and ")) lower.split(" and ") else lower.split(" then ")
            if (steps.size > 1) {
                scope.launch {
                    processVoiceCommand(steps[0].trim())
                    kotlinx.coroutines.delay(2000)
                    processVoiceCommand(steps[1].trim())
                }
                return
            }
        }

        // 5. WhatsApp Voice & Text Bot Commands
        // Pattern: "<name> ko WhatsApp par message bhejo <text>"
        val waMatch = Regex("(.*?) ko whatsapp (par|pe)?\\s*(message|msg)?\\s*bhejo\\s*(.*)", RegexOption.IGNORE_CASE).find(lower)
            ?: Regex("send whatsapp message to (.*?):?\\s*(.*)", RegexOption.IGNORE_CASE).find(lower)

        if (waMatch != null) {
            val recipient = waMatch.groupValues[1].replace("whatsapp", "").trim()
            val messageText = waMatch.groupValues[waMatch.groupValues.size - 1].trim()
            if (recipient.isNotBlank() && messageText.isNotBlank()) {
                postPendingConfirmation(
                    PendingAction(
                        actionType = "whatsapp_send",
                        description = "WhatsApp to $recipient: \"$messageText\"",
                        spokenPrompt = "$boss, $recipient ko WhatsApp par message bhejna hai: \"$messageText\". Bhej doon?",
                        recipient = recipient,
                        messageText = messageText
                    )
                )
                return
            }
        }

        // WhatsApp call: "WhatsApp call lagao <name>"
        if (lower.contains("whatsapp call") || lower.contains("whatsapp par call")) {
            val contactName = lower.replace("whatsapp call", "")
                .replace("whatsapp par call lagao", "")
                .replace("whatsapp call karo", "")
                .replace("ko", "").trim()
            openWhatsAppContact(contactName)
            app.ttsManager.speak("$boss, $contactName ke liye WhatsApp khol diya hai.")
            return
        }

        // Chat summary: "is chat ka summary batao"
        if (lower.contains("summary") || lower.contains("chat ka summary") || lower.contains("chat summarize karo")) {
            scope.launch {
                val apiKey = app.securityManager.activeGeminiKey
                if (apiKey.isBlank()) {
                    app.ttsManager.speak("Gemini off ho gaya hai.")
                    return@launch
                }
                val messages = app.database.chatDao().getAllMessages()
                val transcript = "User: Hello\nAssistant: Welcome Boss\nRecent incoming notifications received on device."
                val summary = app.geminiService.summarizeChat(transcript, apiKey)
                summary.onSuccess { text ->
                    app.ttsManager.speak(text)
                }.onFailure {
                    app.ttsManager.speak("Gemini off ho gaya hai.")
                }
            }
            return
        }

        // 6. Screen OCR Click: "jis par <text> likha hai usko dabao" / "tap on <text>"
        val ocrMatch = Regex("jis par ['\"]?(.*?)['\"]? likha hai usko dabao", RegexOption.IGNORE_CASE).find(lower)
            ?: Regex("(click|tap on|press|dabao) ['\"]?(.*?)['\"]?", RegexOption.IGNORE_CASE).find(lower)

        if (ocrMatch != null && (lower.contains("likha hai") || lower.contains("tap on") || lower.contains("click"))) {
            val target = ocrMatch.groupValues[ocrMatch.groupValues.size - 1]
                .replace("likha hai usko dabao", "")
                .replace("dabao", "")
                .trim()

            if (target.isNotBlank()) {
                val accessibility = MaxAccessibilityService.instance
                if (accessibility != null) {
                    accessibility.clickTextViaOcr(target) { success, msg ->
                        app.ttsManager.speak(msg)
                    }
                } else {
                    app.ttsManager.speak("Boss, kripya Accessibility permission on karein.")
                }
                return
            }
        }

        // 7. Screen Understanding: "is screen par kya hai"
        if (lower.contains("screen par kya hai") || lower.contains("what is on this screen") || lower.contains("explain screen")) {
            val accessibility = MaxAccessibilityService.instance
            if (accessibility != null) {
                app.ttsManager.speak("Screen check kar raha hoon...")
                accessibility.captureCurrentScreen { bitmap ->
                    if (bitmap != null) {
                        scope.launch {
                            val apiKey = app.securityManager.activeGeminiKey
                            if (apiKey.isBlank()) {
                                app.ttsManager.speak("Gemini off ho gaya hai.")
                                return@launch
                            }
                            val res = app.geminiService.understandScreen(bitmap, apiKey)
                            res.onSuccess { text ->
                                app.ttsManager.speak(text)
                            }.onFailure {
                                app.ttsManager.speak("Gemini off ho gaya hai.")
                            }
                        }
                    } else {
                        app.ttsManager.speak("Screen capture nahi ho paya.")
                    }
                }
            } else {
                app.ttsManager.speak("Accessibility service chalu nahi hai.")
            }
            return
        }

        // 8. YouTube Voice Commands: "YouTube par <song> lagao"
        if (lower.contains("youtube par") || lower.contains("play on youtube") || (lower.contains("youtube") && lower.contains("lagao"))) {
            val query = lower.replace("youtube par", "")
                .replace("gaana lagao", "")
                .replace("video lagao", "")
                .replace("lagao", "")
                .replace("chalao", "")
                .replace("play", "")
                .trim()
            openYouTubeSearch(query)
            app.ttsManager.speak("$boss, YouTube par $query chala diya hai.")
            return
        }

        // 9. Instagram Controls: "Instagram kholo", "reels chalao", "next reel"
        val igWord = lower.split(" ").any { it == "instagram" || it == "insta" }
        if (igWord) {
            val wantsOpen = lower.contains("kholo") || lower.contains("open") || lower.contains("chalu") ||
                    lower.contains("chalao") || lower.contains("start") || lower.split(" ").size <= 2
            if (wantsOpen) {
                val ok = openAppByName("Instagram")
                app.ttsManager.speak(if (ok) "$boss, Instagram khol diya hai." else "$boss, Instagram nahi mil raha.")
                return
            }
        }
        if (lower.contains("next reel") || lower.contains("agla reel")) {
            MaxAccessibilityService.instance?.swipeNextReel()
            return
        }
        if (lower.contains("previous reel") || lower.contains("pichhla reel")) {
            MaxAccessibilityService.instance?.swipePreviousReel()
            return
        }
        if (lower.contains("like reel") || lower.contains("like karo")) {
            MaxAccessibilityService.instance?.doubleTapLike()
            app.ttsManager.speak("Reel like kar di.")
            return
        }

        // 10. System Navigation Gestures
        if (lower == "home" || lower == "home jao" || lower == "go home") {
            MaxAccessibilityService.instance?.triggerHome()
            return
        }
        if (lower == "back" || lower == "piche jao" || lower == "go back") {
            MaxAccessibilityService.instance?.triggerBack()
            return
        }
        if (lower == "recents" || lower == "recent apps") {
            MaxAccessibilityService.instance?.triggerRecents()
            return
        }
        if (lower.contains("lock screen") || lower.contains("phone lock karo")) {
            MaxAccessibilityService.instance?.triggerLockScreen()
            return
        }
        if (lower.contains("screenshot lo") || lower.contains("take screenshot")) {
            MaxAccessibilityService.instance?.triggerScreenshot()
            app.ttsManager.speak("Screenshot le liya hai.")
            return
        }
        if (lower.contains("scroll up") || lower.contains("upar karo") || lower.contains("reel upar") || lower.contains("upar scroll") || lower.contains("upar jao") || lower == "upar") {
            MaxAccessibilityService.instance?.scrollUp()
            return
        }
        if (lower.contains("scroll down") || lower.contains("neeche karo") || lower.contains("reel neeche") || lower.contains("neeche scroll") || lower.contains("neeche jao") || lower == "neeche") {
            MaxAccessibilityService.instance?.scrollDown()
            return
        }

        // 11. Hardware Controls: Flashlight, Volume, WiFi, Bluetooth
        if (lower.contains("flashlight on") || lower.contains("torch on") || lower.contains("torch jalao")) {
            setTorch(true)
            app.ttsManager.speak("Torch on kar di.")
            return
        }
        if (lower.contains("flashlight off") || lower.contains("torch off") || lower.contains("torch band")) {
            setTorch(false)
            app.ttsManager.speak("Torch band kar di.")
            return
        }
        if (lower.contains("volume up") || lower.contains("awaz badhao")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            app.ttsManager.speak("Volume badha diya.")
            return
        }
        if (lower.contains("volume down") || lower.contains("awaz kam karo")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            app.ttsManager.speak("Volume kam kar diya.")
            return
        }
        if (lower.contains("mute") || lower.contains("silent karo")) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            app.ttsManager.speak("Phone silent kar diya.")
            return
        }
        if (lower.contains("bluetooth on") || lower.contains("bluetooth open")) {
            context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            app.ttsManager.speak("Bluetooth settings khol di hai.")
            return
        }
        if (lower.contains("wifi on") || lower.contains("wifi open") || lower.contains("wi-fi")) {
            context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            app.ttsManager.speak("Wi-Fi settings khol di hai.")
            return
        }

        // 12. App Launching by Name: "<App Name> kholo" / "open <App Name>" (any installed app)
        if (lower.contains("kholo") || lower.contains("open") || lower.contains("chalu karo") || lower.contains("start karo")) {
            val skip = setOf("kholo", "open", "chalu", "karo", "kar", "do", "start", "please", "mujhe", "mera", "meri",
                "ko", "app", "ka", "ki", "ke", "mein", "me", "jao", "chalao")
            val appQuery = lower.split(Regex("\\s+")).filter { it.isNotBlank() && it !in skip }.joinToString(" ").trim()
            if (appQuery.isNotBlank()) {
                if (openAppByName(appQuery)) {
                    app.ttsManager.speak("$boss, $appQuery khol diya hai.")
                } else {
                    scope.launch {
                        if (openAppWithGemini(appQuery)) {
                            app.ttsManager.speak("$boss, $appQuery khol diya hai.")
                        } else {
                            app.ttsManager.speak("$boss, $appQuery naam ki app nahi mili.")
                        }
                    }
                }
                return
            }
        }

        // 12b. Just saying an installed app's name opens it.
        if (lower.split(" ").size <= 3 && openAppByName(lower, strict = true)) {
            app.ttsManager.speak("$boss, $lower khol diya hai.")
            return
        }

        // 13. AI brain: understands free-form speech, then acts or chats like a person.
        askBrain(normalized, fromAi)
    }

    private val recentChat = mutableListOf<ChatMessage>()

    private fun rememberChat(sender: String, text: String) {
        recentChat.add(ChatMessage(sender = sender, text = text))
        while (recentChat.size > 8) recentChat.removeAt(0)
    }

    private fun nowContext(): String {
        val bm = context.getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager
        val pct = bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val t = java.text.SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", java.util.Locale.getDefault()).format(java.util.Date())
        return "Now: $t. Battery $pct%."
    }

    private fun brainSystemPrompt(): String {
        val name = app.securityManager.assistantName
        val boss = app.securityManager.userCallName
        val female = app.securityManager.voiceGender.equals("Female", ignoreCase = true)
        val notes = MemoryNotes.list(context).takeLast(15)
        val memory = if (notes.isEmpty()) "" else "\nThings $boss asked you to remember: " + notes.joinToString("; ")
        return """You are $name, a warm, caring and very smart ${if (female) "female" else "male"} voice assistant living inside $boss's Android phone. You talk like a close, clever friend: short, natural, with real feelings, and you think before you answer. Call the user "$boss". The message starts with the current time and battery in square brackets; use it when useful.
LANGUAGE: if $boss speaks Hindi or Hinglish, write the "reply" in Hindi using Devanagari script (so the voice sounds natural). If $boss speaks English, reply in English. Keep every "commands" entry in Roman letters.
Reply with ONLY one JSON object, no markdown, in one of these two shapes:
{"type":"chat","reply":"<what you say>","emotion":"happy|sad|angry|surprised|thinking|neutral|love|sleepy"}
{"type":"commands","commands":["<phone command>","..."],"emotion":"happy|neutral|thinking"}
Use "commands" when $boss wants the phone to DO something. Every command must be a short Hinglish command from this list only: "youtube kholo", "youtube par <song> lagao", "<app name> kholo", "<name> ko call karo", "whatsapp par <name> ko message bhejo <text>", "upar karo", "neeche karo", "next reel", "pichhla reel", "like karo", "volume badhao", "volume kam karo", "bluetooth on karo", "wifi off karo", "torch on karo", "screenshot lo", "home jao", "back jao", "alarm lagao 7 baje", "timer lagao 5 minute", "<place> ka rasta batao", "google par <query> search karo", "<text> yaad dilao 5 baje", "<fact> yaad rakho", "next song", "gaana roko".
Use "chat" for questions, jokes, advice, feelings, maths, translation, general knowledge and planning. For casual talk use 1-2 short sentences. For questions, problems and explanations give the complete, correct answer clearly (up to 6 short sentences, step by step for a problem). Think carefully and be accurate. If you are not sure, say so honestly or ask one short question. Never claim you did something you did not. Never invent other commands.
Examples:
"bhai youtube pe arijit ke gaane laga do" -> {"type":"commands","commands":["youtube par arijit singh ka gaana lagao"],"emotion":"happy"}
"mummy ko phone lagao" -> {"type":"commands","commands":["mummy ko call karo"],"emotion":"neutral"}
"aaj mood kharab hai" -> {"type":"chat","reply":"अरे बॉस, क्या हुआ? मुझसे बात करो, मैं यहीं हूँ।","emotion":"sad"}$memory"""
    }

    private fun looksLikeQuestion(l: String): Boolean {
        val words = l.split(" ").filter { it.isNotBlank() }
        if (words.size < 3) return false
        val q = setOf("kaun", "kon", "kya", "kyun", "kyu", "kaise", "kaisa", "kitna", "kitni", "kitne", "kab", "kahan", "kidhar",
            "who", "what", "why", "how", "when", "where", "which", "explain", "samjhao", "batao", "bataiye", "tell",
            "define", "meaning", "matlab", "solve", "calculate")
        val action = setOf("kholo", "open", "call", "lagao", "chalao", "bhejo", "message", "volume", "bluetooth", "wifi", "torch",
            "screenshot", "alarm", "timer", "scroll", "upar", "neeche", "reel", "like", "back", "home", "play", "pause", "next",
            "brightness", "unlock", "dabao", "tap", "click", "whatsapp", "youtube", "instagram")
        val hasQuestion = words.any { it in q } || l.endsWith("?")
        val hasAction = words.any { it in action }
        return hasQuestion && !hasAction
    }

    private fun askBrain(text: String, fromAi: Boolean) {
        if (fromAi) {
            app.ttsManager.speak("Samajh nahi aaya.")
            return
        }
        val sm = app.securityManager
        val key = sm.activeGeminiKey
        val offlineReady = OfflineBrain.isReady(context)
        val prompted = "[${nowContext()}] $text"
        Diagnostics.lastError.value = ""

        // No key, or "offline only": use the on-device brain.
        if (sm.offlineOnly || key.isBlank()) {
            if (offlineReady) askOffline(text, prompted) else app.ttsManager.speak("Gemini off ho gaya hai.")
            return
        }
        AvatarState.setManual("thinking")
        Diagnostics.brain.value = "Gemini"
        scope.launch {
            val res = app.geminiService.generateReply(prompted, recentChat.toList(), brainSystemPrompt(), key)
            res.onSuccess { raw ->
                handleBrainReply(text, raw)
            }.onFailure { err ->
                Diagnostics.lastError.value = (err.message ?: "Gemini error").take(120)
                // Gemini busy or no internet: fall back to the on-device brain.
                if (offlineReady) askOffline(text, prompted) else app.ttsManager.speak("Gemini off ho gaya hai.")
            }
        }
    }

    private fun askOffline(original: String, prompted: String) {
        AvatarState.setManual("thinking")
        Diagnostics.brain.value = "Offline"
        if (!OfflineBrain.loaded) app.ttsManager.speak("एक सेकंड, सोच रहा हूँ।")
        scope.launch {
            val res = OfflineBrain.reply(context, prompted, brainSystemPrompt(), app.securityManager.offlineGpu)
            res.onSuccess { raw ->
                handleBrainReply(original, raw)
            }.onFailure { err ->
                Diagnostics.lastError.value = (err.message ?: "Offline error").take(120)
                app.ttsManager.speak("Offline dimaag chalu nahi ho paya.")
            }
        }
    }

    private fun handleBrainReply(userText: String, raw: String) {
        var json: JSONObject? = null
        try {
            val a = raw.indexOf('{')
            val b = raw.lastIndexOf('}')
            if (a >= 0 && b > a) json = JSONObject(raw.substring(a, b + 1))
        } catch (e: Exception) {
            json = null
        }
        rememberChat("user", userText)

        if (json == null) {
            val m = Regex("\"reply\"\\s*:\\s*\"([^\"]*)").find(raw)
            val reply = (m?.groupValues?.get(1) ?: raw.replace(Regex("[{}\"]"), " ")).trim().take(1200)
            rememberChat("assistant", reply)
            app.ttsManager.speakWithEmotion(reply, AvatarState.guess(reply), app.securityManager.voiceSpeed, app.securityManager.voicePitch)
            return
        }

        val emotion = json.optString("emotion", "neutral")
        if (json.optString("type", "chat") == "commands") {
            val arr = json.optJSONArray("commands")
            val cmds = mutableListOf<String>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val c = arr.optString(i).trim()
                    if (c.isNotBlank()) cmds.add(c)
                }
            }
            rememberChat("assistant", "done: " + cmds.joinToString("; "))
            AvatarState.setManual(emotion)
            scope.launch {
                for ((i, c) in cmds.withIndex()) {
                    if (i > 0) kotlinx.coroutines.delay(2500)
                    processVoiceCommand(c, true)
                }
            }
        } else {
            val reply = json.optString("reply", "").ifBlank { "Samajh nahi aaya." }
            rememberChat("assistant", reply)
            scope.launch {
                app.database.chatDao().insertMessage(ChatMessage(sender = "assistant", text = reply))
            }
            app.ttsManager.speakWithEmotion(reply, emotion, app.securityManager.voiceSpeed, app.securityManager.voicePitch)
        }
    }

    private fun playOnYouTube(query: String) {
        val app = context.applicationContext as MaxApplication
        val boss = app.securityManager.userCallName
        app.ttsManager.speak("$boss, YouTube par $query dhundh raha hoon.")
        openYouTubeSearch(query)
        scope.launch {
            val acc = { MaxAccessibilityService.instance }
            if (acc() == null) {
                app.ttsManager.speak("$boss, search khol diya hai. Gaana khud chalane ke liye Accessibility service chalu karein.")
                return@launch
            }
            val firstWord = query.split(" ").first()
            // Wait until the search results screen is showing.
            var waited = 0
            kotlinx.coroutines.delay(2500)
            while (waited < 10000 && acc()?.screenContainsText(firstWord) != true) {
                kotlinx.coroutines.delay(700)
                waited += 700
            }
            kotlinx.coroutines.delay(1800)
            var clicked = false
            var tries = 0
            while (!clicked && tries < 4) {
                clicked = acc()?.clickFirstYouTubeVideo() == true
                if (!clicked) kotlinx.coroutines.delay(1200)
                tries++
            }
            if (clicked) {
                app.ttsManager.speak("$boss, $query chala diya hai.")
            } else {
                app.ttsManager.speak("$boss, search ho gaya hai par video chalu nahi kar paya. Aap pehle video par tap kar dijiye.")
            }
        }
    }

    /** Converts common Devanagari speech-recognition output into the Roman keywords the parser understands. */
    private fun normalizeHindi(input: String): String {
        if (!input.any { it in '\u0900'..'\u097F' }) return input
        val map = listOf(
            "यू ट्यूब" to "youtube", "यूट्यूब" to "youtube", "यूटयूब" to "youtube", "यूटूब" to "youtube",
            "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp",
            "इंस्टाग्राम" to "instagram", "इंस्टा" to "instagram", "फेसबुक" to "facebook",
            "खोल दो" to "kholo", "खोलिए" to "kholo", "खोलो" to "kholo", "खोल" to "kholo",
            "लगा दो" to "lagao", "लगाइए" to "lagao", "लगाओ" to "lagao", "लगा" to "lagao",
            "चला दो" to "chalao", "चलाओ" to "chalao", "चलाइए" to "chalao", "बजाओ" to "bajao", "सुनाओ" to "sunao",
            "गाना" to "gaana", "गाने" to "gaana", "गीत" to "gaana", "वीडियो" to "video", "म्यूजिक" to "music", "सॉन्ग" to "song",
            "ढूंढो" to "dhundo", "खोजो" to "khojo", "सर्च" to "search",
            "पर" to "par", "पे" to "pe", "और" to "aur", "का" to "ka", "के" to "ke", "की" to "ki", "को" to "ko",
            "मैसेज" to "message", "भेजो" to "bhejo", "भेज दो" to "bhejo", "कॉल" to "call",
            "रील" to "reel", "रिल" to "reel", "अगला" to "agla", "पिछला" to "pichhla", "लाइक" to "like",
            "ऊपर" to "upar", "नीचे" to "neeche", "करो" to "karo", "कर दो" to "karo", "स्क्रॉल" to "scroll",
            "वॉल्यूम" to "volume", "आवाज" to "awaz", "आवाज़" to "awaz", "बढ़ाओ" to "badhao", "बढ़ा दो" to "badhao", "कम" to "kam",
            "ब्लूटूथ" to "bluetooth", "वाईफाई" to "wifi", "वाई-फाई" to "wifi", "चालू" to "chalu", "बंद" to "band",
            "होम" to "home", "पीछे" to "piche", "जाओ" to "jao", "कैमरा" to "camera", "टॉर्च" to "torch", "जलाओ" to "jalao",
            "स्क्रीनशॉट" to "screenshot", "सेटिंग्स" to "settings", "सेटिंग" to "settings", "ऐप" to "app",
            "नाम" to "naam", "रख दो" to "rakh do", "रखो" to "rakho", "बदलो" to "badlo", "बदल" to "badal",
            "तुम्हारा" to "tumhara", "तुम्हारी" to "tumhari", "अपना" to "apna", "आपका" to "aapka", "तेरा" to "tera",
            "याद दिलाना" to "yaad dilana", "याद दिलाओ" to "yaad dilao", "याद दिला दो" to "yaad dila do", "याद रखो" to "yaad rakho", "याद रखना" to "yaad rakho",
            "कल" to "kal", "सुबह" to "subah", "शाम" to "shaam", "रात" to "raat", "दोपहर" to "dopahar", "बाद" to "baad", "घंटे" to "ghante",
            "कहाँ" to "kahan", "कहां" to "kahan", "गुड नाइट" to "good night", "शुभ रात्रि" to "shubh ratri", "गुड मॉर्निंग" to "good morning",
            "सुप्रभात" to "suprabhat", "नया" to "naya", "मैसेज" to "message",
            "क्यू आर" to "qr", "क्यूआर" to "qr", "निकाल दो" to "nikalo", "निकालो" to "nikalo", "दिखा दो" to "dikhao", "दिखाओ" to "dikhao",
            "फोनपे" to "phonepe", "पेटीएम" to "paytm", "क्रोम" to "chrome", "जीमेल" to "gmail", "मैप्स" to "maps", "टेलीग्राम" to "telegram",
            "स्नैपचैट" to "snapchat", "नेटफ्लिक्स" to "netflix", "स्पॉटिफाई" to "spotify", "अमेज़न" to "amazon", "अमेजन" to "amazon",
            "फ्लिपकार्ट" to "flipkart", "कैलकुलेटर" to "calculator", "गैलरी" to "gallery", "फोटोज" to "photos", "फोटो" to "photo",
            "प्ले स्टोर" to "playstore", "गूगल पे" to "googlepay", "जीपे" to "gpay",
            "अनलॉक" to "unlock", "जेमिनी" to "gemini", "ऑफ" to "off", "ऑन" to "on", "मोबाइल" to "mobile",
            "उठा लो" to "uthao", "उठाओ" to "uthao", "रिसीव" to "receive", "काटो" to "kaato", "कट" to "cut",
            "बजे" to "baje", "अलार्म" to "alarm", "टाइमर" to "timer", "मिनट" to "minute", "सेकंड" to "second", "घंटा" to "ghanta",
            "बैटरी" to "battery", "कितनी" to "kitni", "कितने" to "kitne", "तारीख" to "tarikh", "आज" to "aaj", "क्या" to "kya", "टाइम" to "time",
            "रास्ता" to "rasta", "बताओ" to "batao", "नेविगेट" to "navigate", "गूगल" to "google", "स्पीकर" to "speaker", "रोको" to "roko",
            "डायल" to "dial", "फोन" to "phone", "नोटिफिकेशन" to "notification", "दबाओ" to "dabao", "लिखो" to "likho",
            "हाँ" to "haan", "हां" to "haan", "नहीं" to "nahi", "ठीक है" to "theek hai", "रुको" to "ruk jao", "चुप" to "chup"
        )
        var out = input
        for ((hi, en) in map) {
            val rx = Regex("(?<![\\u0900-\\u097F])" + Regex.escape(hi) + "(?![\\u0900-\\u097F])")
            out = rx.replace(out, en)
        }
        out = out.map { ch -> if (ch in '\u0966'..'\u096F') ('0' + (ch - '\u0966')) else ch }.joinToString("")
        return out
    }

    private fun isAffirmative(text: String): Boolean {
        return text == "yes" || text == "haan" || text == "ha" || text == "bhej do" || text == "bhejo" ||
                text == "kar do" || text == "ok" || text == "theek hai" || text == "sure" || text.contains("haan")
    }

    private fun isNegative(text: String): Boolean {
        return text == "no" || text == "nahi" || text == "na" || text == "cancel" || text == "mat bhejo" || text == "ruk jao"
    }

    private fun setTorch(state: Boolean) {
        try {
            val id = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(id, state)
            isTorchOn = state
        } catch (e: Exception) {
            Log.e("PhoneCommander", "Torch error", e)
        }
    }

    private val appAliases = mapOf(
        "insta" to "instagram", "ig" to "instagram",
        "watsapp" to "whatsapp", "whatsap" to "whatsapp", "wa" to "whatsapp",
        "yt" to "youtube", "utube" to "youtube",
        "fb" to "facebook", "gpay" to "googlepay",
        "gallery" to "photos", "browser" to "chrome", "googlemaps" to "maps",
        "sms" to "messages", "dialer" to "phone", "snap" to "snapchat", "tg" to "telegram"
    )

    private val knownPackages = mapOf(
        "instagram" to "com.instagram.android", "whatsapp" to "com.whatsapp",
        "youtube" to "com.google.android.youtube", "facebook" to "com.facebook.katana",
        "telegram" to "org.telegram.messenger", "snapchat" to "com.snapchat.android",
        "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps", "spotify" to "com.spotify.music",
        "netflix" to "com.netflix.mediaclient", "phonepe" to "com.phonepe.app",
        "paytm" to "net.one97.paytm", "googlepay" to "com.google.android.apps.nbu.paisa.user",
        "playstore" to "com.android.vending", "photos" to "com.google.android.apps.photos",
        "amazon" to "in.amazon.mShop.android.shopping", "flipkart" to "com.flipkart.android"
    )

    private fun launchPackage(pkg: String): Boolean {
        val launch = context.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(launch)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Opens any installed app by the name the user says. strict=true only accepts close name matches. */
    private fun openAppByName(query: String, strict: Boolean = false): Boolean {
        val pm = context.packageManager
        val cleaner = Regex("[^a-z0-9\\u0900-\\u097F]")
        var q = query.lowercase().replace(cleaner, "")
        if (q.isBlank()) return false
        q = appAliases[q] ?: q

        // 1) Well-known apps by package name.
        val pkg = knownPackages[q]
        if (pkg != null && launchPackage(pkg)) return true

        // 2) Best match among every installed launcher app.
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        var best: String? = null
        var bestScore = 0
        for (info in pm.queryIntentActivities(mainIntent, 0)) {
            val label = info.loadLabel(pm).toString().lowercase().replace(cleaner, "")
            if (label.isBlank()) continue
            val score = when {
                label == q -> 100
                q.length >= 3 && label.startsWith(q) -> 80
                label.length >= 3 && q.startsWith(label) -> 70
                !strict && q.length >= 3 && label.contains(q) -> 60
                !strict && label.length >= 4 && q.contains(label) -> 50
                else -> 0
            }
            if (score > bestScore) {
                bestScore = score
                best = info.activityInfo.packageName
            }
        }
        return best != null && launchPackage(best)
    }

    /** Last resort for Hindi or unusual spellings: let Gemini pick the app from the installed list. */
    private suspend fun openAppWithGemini(spoken: String): Boolean {
        val key = app.securityManager.activeGeminiKey
        if (key.isBlank()) return false
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply { addCategory(Intent.CATEGORY_LAUNCHER) }
        val infos = pm.queryIntentActivities(mainIntent, 0)
        val labels = infos.map { it.loadLabel(pm).toString() }.distinct().take(300)
        val prompt = "Spoken app name: \"$spoken\" (may be Hindi script or Hinglish). Installed apps: ${labels.joinToString(" | ")}. " +
                "Reply with ONLY the single best matching app name exactly as written in the list, or NONE."
        val res = app.geminiService.generateReply(prompt, emptyList(), "You match spoken app names to installed apps. Output only the app name or NONE.", key)
        val answer = res.getOrNull()?.trim()?.trim('"') ?: return false
        val hit = infos.firstOrNull { it.loadLabel(pm).toString().equals(answer, ignoreCase = true) } ?: return false
        return launchPackage(hit.activityInfo.packageName)
    }

    private fun openYouTubeSearch(query: String) {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
            setPackage("com.google.android.youtube")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        }
    }

    private fun openWhatsAppContact(name: String) {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("whatsapp://send")
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val fallback = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }

    private fun openWhatsAppMessage(recipient: String, message: String) {
        val encoded = URLEncoder.encode(message, "UTF-8")
        val intent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://api.whatsapp.com/send?text=$encoded")
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val genericIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(genericIntent)
        }
    }

    @SuppressLint("MissingPermission")
    private fun makeDirectPhoneCall(phone: String) {
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(dialIntent)
        }
    }
}
