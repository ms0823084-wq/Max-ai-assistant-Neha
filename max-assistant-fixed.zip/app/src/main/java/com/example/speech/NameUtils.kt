package com.example.speech

import java.util.Locale

/**
 * Helps the assistant recognise ANY name the user gives it (Neha, Riya, Zia, Jarvis...).
 * The speech recogniser often writes Hindi names in Devanagari, so we also build likely Devanagari spellings.
 */
object NameUtils {
    private val cons2 = linkedMapOf(
        "chh" to "छ", "ch" to "च", "sh" to "श", "kh" to "ख", "gh" to "घ",
        "th" to "थ", "dh" to "ध", "ph" to "फ", "bh" to "भ", "jh" to "झ"
    )
    private val cons1 = mapOf(
        'k' to "क", 'g' to "ग", 'c' to "क", 'j' to "ज", 't' to "त", 'd' to "द", 'n' to "न",
        'p' to "प", 'b' to "ब", 'm' to "म", 'y' to "य", 'r' to "र", 'l' to "ल", 'v' to "व",
        'w' to "व", 's' to "स", 'h' to "ह", 'f' to "फ", 'z' to "ज", 'q' to "क", 'x' to "क्स"
    )
    private val vowelList = listOf("aa", "ee", "ii", "oo", "uu", "ai", "au", "a", "i", "u", "o", "e")
    private val independent = mapOf(
        "aa" to "आ", "ee" to "ई", "ii" to "ई", "oo" to "ऊ", "uu" to "ऊ", "ai" to "ऐ", "au" to "औ",
        "a" to "अ", "i" to "इ", "u" to "उ", "o" to "ओ", "e" to "ए"
    )
    private val matra = mapOf(
        "aa" to "ा", "ee" to "ी", "ii" to "ी", "oo" to "ू", "uu" to "ू", "ai" to "ै", "au" to "ौ",
        "a" to "", "i" to "ि", "u" to "ु", "o" to "ो", "e" to "े"
    )

    /** Rough Roman to Devanagari spelling ("neha" -> "नेहा"). */
    fun toDevanagari(name: String, longFinal: Boolean): String {
        val w = name.lowercase(Locale.ROOT).filter { it in 'a'..'z' }
        val sb = StringBuilder()
        var i = 0
        var afterConsonant = false
        var atStart = true
        while (i < w.length) {
            val v = vowelList.firstOrNull { w.startsWith(it, i) }
            if (v != null) {
                val isFinal = i + v.length == w.length
                var m = matra[v] ?: ""
                if (isFinal && v == "a") m = "ा"
                if (isFinal && v == "i" && longFinal) m = "ी"
                if (afterConsonant) {
                    sb.append(m)
                } else if (atStart) {
                    sb.append(independent[v] ?: "")
                } else {
                    sb.append("य").append(m)
                }
                afterConsonant = false
                atStart = false
                i += v.length
                continue
            }
            val two = cons2.entries.firstOrNull { w.startsWith(it.key, i) }
            val cons: String
            val len: Int
            if (two != null) {
                cons = two.value
                len = two.key.length
            } else {
                cons = cons1[w[i]] ?: ""
                len = 1
            }
            if (afterConsonant) sb.append("्")
            sb.append(cons)
            afterConsonant = true
            atStart = false
            i += len
        }
        return sb.toString()
    }

    /** Every spelling that should wake the assistant for this name. */
    fun variants(roman: String, hindi: String): List<String> {
        val n = roman.lowercase(Locale.ROOT).trim()
        val out = linkedSetOf<String>()
        if (n.isNotBlank()) out.add(n)
        if (hindi.isNotBlank()) out.add(hindi.trim())
        if (n == "max") {
            out.addAll(listOf("macs", "maxx", "maks", "मैक्स", "मैक्सी", "मैक्सि", "मेक्स", "मैक"))
        }
        if (n.isNotBlank() && n.all { it in 'a'..'z' }) {
            for (longFinal in listOf(true, false)) {
                val base = toDevanagari(n, longFinal)
                out.add(base)
                out.add(base.replace(Regex("[नम]्(?=[क-ह])"), "ं"))
            }
        }
        return out.filter { it.isNotBlank() }
    }
}
